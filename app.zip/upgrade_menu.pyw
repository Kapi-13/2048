# pyright: reportMissingTypeStubs=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportUnknownVariableType=false

from customtkinter import CTk, CTkLabel, CTkFrame, CTkButton
from sys import executable, exit
from subprocess import Popen
from os import path
import presets


scale = presets.scale

def back_to_menu() -> None:
    current_dir = path.dirname(path.abspath(__file__))
    sciezka_do_pliku = path.join(current_dir, "main_menu.pyw")
    Popen([executable, sciezka_do_pliku])
    app.destroy()
    exit()

app = CTk()
app.title("2048 - Ulepszenia")
app.geometry(f"{int(scale * 260)}x{int(scale * 200 - 42)}")
app.resizable(False, False)
app.protocol("WM_DELETE_WINDOW", back_to_menu)

# app.grid_columnconfigure

title = CTkLabel(app, text="2048 - Ulepszenia", font=("Arial", int(scale * 18), "bold"))
# title.place(rely=0.0, relx=0.5, anchor="n")

upgrades = CTkFrame(app, border_width=1, border_color="lightgreen")
# upgrades.place(rely=0.5, relx=0.5, anchor="center")

app.mainloop()
