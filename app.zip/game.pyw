# pyright: reportMissingTypeStubs=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportUnknownVariableType=false

# Libraries
import sys
sys.dont_write_bytecode = True

from customtkinter import CTk, CTkLabel, CTkFrame, CTkButton, CTkImage
from PIL import ImageGrab, ImageFilter
from subprocess import Popen
from json import load
from os import path, execl
from decimal import Decimal
# My modules
from modules.movement_modules import move_up, move_down, move_left, move_right, set_score
from modules.over_module import check_game_over
from modules.label_module import random_spawn
from utils.utils import refresh, animate
import presets

scale = presets.scale
mode = presets.mode

labels_grid: list[list[CTkLabel]]
score: CTkLabel


def back_to_menu() -> None:
    current_dir = path.dirname(path.abspath(__file__))
    sciezka_do_pliku = path.join(current_dir, "main_menu.pyw")
    Popen([sys.executable, sciezka_do_pliku])
    app.destroy()
    sys.exit()


app = CTk(fg_color="#bbada0")
app.title("2048 - Główna gra")
app.geometry(f"{int(scale * 300)}x{int(scale * 300 - 42)}")
# app.resizable(False, False)
app.minsize(int(scale * 300), int(scale * 300 - 42))
# app.protocol("WM_DELETE_WINDOW", back_to_menu)

top_frame = CTkFrame(app, fg_color="#bbada0")
bottom_frame = CTkFrame(app, fg_color="#9c8b7c")

app.grid_rowconfigure(0, weight=0)
app.grid_rowconfigure(1, weight=1)
app.grid_columnconfigure(0, weight=1)


top_frame.grid(row=0, column=0, sticky="ew")
bottom_frame.grid(row=1, column=0)

top_frame.grid_columnconfigure(0, weight=1)
top_frame.grid_columnconfigure(1, weight=1)
top_frame.grid_rowconfigure(0, weight=1)
top_frame.grid_rowconfigure(1, weight=1)


def animate_score(pos: Decimal = Decimal("0.2"), added_score: CTkLabel | None = None):
    print(pos)
    if added_score is None:
        added_score = CTkLabel(top_frame, text="+ 20", font=("Arial", int(scale * 14)), text_color="#00ff00")
    added_score.place(relx=0.25, rely=float(f"{pos}"), anchor="n")
    animate(pos, added_score, "advanced")
    if pos == Decimal("0.0"):
        app.after(150, added_score.destroy)
    else:
        app.after(75, lambda: animate_score(pos - Decimal("0.05"), added_score))


def start() -> None:
    global labels_grid, score
    labels_grid = [[], [], [], []]
    for j in range(4):
        bottom_frame.grid_columnconfigure(j, weight=1)

    score = CTkLabel(top_frame, text="Wynik: 0", font=("Arial", int(scale * 14)))

    with open("data/data.json", "r", encoding="utf-8") as file:
        data = load(file)
    best_score = CTkLabel(top_frame, text=f"Najlepszy wynik: {data['best_score']}", font=("Arial", int(scale * 14)), text_color="#efe935")

    set_score(score, data["best_score"], best_score, app, top_frame, scale)
    title = CTkLabel(top_frame, text="2048", font=("Arial", int(scale * 20), "bold"), text_color="#776e65")
    title.grid(row=0, column=0, columnspan=2, sticky="ew")
    score.grid(row=1, column=0)
    best_score.grid(row=1, column=1)

    text = ""
    if mode == 2:
        text = "1"

    for i in range(len(labels_grid)):
        bottom_frame.grid_rowconfigure(i, weight=1)
        for j in range(4):
            if mode == 1:
                text = f"{i, j}"
            elif mode == 2:
                text = str(int(text) * 2)
            labels_grid[i].append(
                CTkLabel(
                    bottom_frame,
                    height=int(scale * 50),
                    width=int(scale * 50),
                    text=f"{text}",
                    font=("Arial", int(scale * 20), "bold"),
                    corner_radius=5,
                    fg_color="#cdc1b4",
                )
            )
            if mode == 2:
                refresh(labels_grid[i][j], text)
            labels_grid[i][j].grid(row=i, column=j, padx=int(scale * 4), pady=int(scale * 4))
    random_spawn(labels_grid)


start()


def helper_func(labels_grid: list[list[CTkLabel]]) -> None:
    random_spawn(labels_grid)
    if check_game_over(labels_grid):

        def show_game_over() -> None:

            x, y, w, h = app.winfo_rootx(), app.winfo_rooty(), app.winfo_width(), app.winfo_height()
            img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
            blurred_img = img.filter(ImageFilter.GaussianBlur(radius=2))
            ctk_img = CTkImage(light_image=blurred_img, dark_image=blurred_img, size=(int(scale * 300), int(scale * 300 - 42)))
            tlo_blur = CTkLabel(app, image=ctk_img, text="")
            tlo_blur.place(x=0, y=0, relwidth=1.0, relheight=1.0)
            app.unbind("<Key-Up>")
            app.unbind("<Key-Down>")
            app.unbind("<Key-Left>")
            app.unbind("<Key-Right>")
            app.unbind("<Key-w>")
            app.unbind("<Key-s>")
            app.unbind("<Key-a>")
            app.unbind("<Key-d>")
            game_over_screen = CTkFrame(app, corner_radius=10, fg_color="transparent", width=int(scale * 200), height=int(scale * 150))
            game_over = CTkLabel(game_over_screen, text="Game Over!", font=("Arial", int(scale * 18)))
            game_over.place(relx=0.5, rely=0.15, anchor="center")
            score_lab = CTkLabel(game_over_screen, text=score.cget("text"), font=("Arial", int(scale * 14)))
            score_lab.place(relx=0.5, rely=0.3, anchor="center")
            back_to_menu_btn = CTkButton(game_over_screen, text="Powrót do menu!", font=("Arial", int(scale * 12)), command=lambda: back_to_menu())
            back_to_menu_btn.place(relx=0.5, rely=0.6, anchor="center")
            restart = CTkButton(game_over_screen, text="Restart!", font=("Arial", int(scale * 12)), command=lambda: execl(sys.executable, sys.executable, *sys.argv))
            restart.place(relx=0.5, rely=0.8, anchor="center")
            game_over_screen.place(relx=0.5, rely=0.5, anchor="center")
            game_over_screen.lift()

        app.after(50, show_game_over)


app.bind("<Key-Up>", lambda e: (move_up(labels_grid), helper_func(labels_grid)))
app.bind("<Key-Down>", lambda e: (move_down(labels_grid), helper_func(labels_grid)))
app.bind("<Key-Left>", lambda e: (move_left(labels_grid), helper_func(labels_grid)))
app.bind("<Key-Right>", lambda e: (move_right(labels_grid), helper_func(labels_grid)))

app.bind("<Key-w>", lambda e: (move_up(labels_grid), helper_func(labels_grid)))
app.bind("<Key-s>", lambda e: (move_down(labels_grid), helper_func(labels_grid)))
app.bind("<Key-a>", lambda e: (move_left(labels_grid), helper_func(labels_grid)))
app.bind("<Key-d>", lambda e: (move_right(labels_grid), helper_func(labels_grid)))
app.bind("<Key-g>", lambda e: animate_score())
app.mainloop()
