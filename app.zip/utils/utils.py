# pyright: reportMissingTypeStubs=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportUnknownVariableType=false
from customtkinter import CTkLabel, CTkFrame, CTk
from decimal import Decimal
from json import load, dump
from typing import Literal
class test:
    def __init__(self):
        self.score = 0
    def test(self):
        pass

def refresh(label: CTkLabel, text: str) -> None:
    change_text(label, text)
    value = label.cget("text")

    def change(fg_col: str, text_col: str) -> None:
        label.configure(fg_color=fg_col, text_color=text_col)

    match value:
        case "":
            change("#cdc1b4", "#000000")
        case "2":
            change("#eee4da", "#776e65")
        case "4":
            change("#ede0c8", "#776e65")
        case "8":
            change("#f2b179", "#f9f6f2")
        case "16":
            change("#f59563", "#f9f6f2")
        case "32":
            change("#f67c5f", "#f9f6f2")
        case "64":
            change("#f65e3b", "#f9f6f2")
        case "128":
            change("#edcf72", "#f9f6f2")
        case "256":
            change("#edcc61", "#f9f6f2")
        case "512":
            change("#edc850", "#f9f6f2")
        case "1024":
            change("#edc53f", "#f9f6f2")
        case "2048":
            change("#edc22e", "#f9f6f2")
        case "4096":
            change("#a6bc09", "#f9f6f2")
        case "8192":
            change("#ff2020", "#f9f6f2")
        case "16384":
            change("#6600cc", "#f9f6f2")
        case "32768":
            change("#007aff", "#f9f6f2")
        case _:
            pass


def change_text(label: CTkLabel, text: str) -> None:
    label.configure(text=text)

def animate(col:Decimal, lbl:CTkLabel, type:Literal["simplified", "advanced"] = "advanced") -> None:
    if type == "simplified":
        if col == Decimal("0.2"):
            lbl.configure(text_color="#00FF00")# Pozycja 0 (soczysty zielony)
        elif col == Decimal("0.1"):
            lbl.configure(text_color="#3EE435")# Pozycja 33
        elif col == Decimal("0.0"):
            lbl.configure(text_color="#7BC96A")# Pozycja 66
    elif type == "advanced":
        if col == Decimal("0.2"):
            lbl.configure(text_color="#00FF00")# Pozycja 0 (soczysty zielony)
        elif col == Decimal("0.15"):
            lbl.configure(text_color="#25EF20")# Pozycja 20
        elif col == Decimal("0.1"):
            lbl.configure(text_color="#4BDE40")# Pozycja 40
        elif col == Decimal("0.05"):
            lbl.configure(text_color="#71CD61")# Pozycja 60
        elif col == Decimal("0.0"):
            lbl.configure(text_color="#96BD81")# Pozycja 80
        else:
            print(f"Nie ok, bo col to {col}.")

def animate_score(top_frame: CTkFrame, scale: float, app: CTk, score_added: int, score_type: Literal["only-score", "score-and-best-score"], added_score: CTkLabel | None = None, added_best_score: CTkLabel | None = None, pos: Decimal = Decimal("0.2")):
    if added_score is None:
        added_score = CTkLabel(top_frame, text=f"+ {score_added}", font=("Arial", int(scale * 14)), text_color="#00ff00")
    if score_type == "score-and-best-score" and added_best_score is None:
        added_best_score = CTkLabel(top_frame, text=f"+ {score_added}", font=("Arial", int(scale * 14)), text_color="#00ff00")
    added_score.place(relx=0.25, rely=float(f"{pos}"), anchor="n")
    animate(pos, added_score, "advanced")
    if score_type == "score-and-best-score" and added_best_score is not None:
        added_best_score.place(relx=0.85, rely=float(f"{pos}"), anchor="n")
        animate(pos, added_best_score, "advanced")
    if pos == Decimal("0.0"):
        app.after(150, added_score.destroy)
        if score_type == "score-and-best-score" and added_best_score is not None:
            app.after(150, added_best_score.destroy)
    else:
        app.after(75, lambda: animate_score(top_frame, scale, app, score_added, score_type, added_score, added_best_score, pos - Decimal("0.05")))


class score_manager:
    def __init__(self):
        self.score = 0

    def change(self, label: CTkLabel, score: int, best_score: int, best_score_label: CTkLabel, app: CTk, top_frame: CTkFrame, scale: float) -> None:
        label.configure(text=f"Wynik: {score}", text_color="#000000")
        difference = score - self.score
        self.score = score
        if difference != 0:
            if score >= best_score:
                animate_score(top_frame, scale, app, difference, "score-and-best-score")
            else:
                animate_score(top_frame, scale, app, difference, "only-score")
        with open("data/data.json", "r", encoding="utf-8") as file:
            data = load(file)
            cash = difference / 2
            data["cash"] += cash * data["upgrades"]["cash_multiplier"]
        if score >= best_score:
            best_score = score
            label.configure(text_color="#efe935")
            best_score_label.configure(text=f"Najlepszy wynik: {best_score}")
            data["best_score"] = best_score
        with open("data/data.json", "w", encoding="utf-8") as file:
            dump(data, file, indent=4, ensure_ascii=False)


score = score_manager()
