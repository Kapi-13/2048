# pyright: reportMissingTypeStubs=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportUnknownVariableType=false
import sys
sys.dont_write_bytecode = True
from customtkinter import CTk, CTkButton, CTkLabel, CTkImage
from subprocess import Popen
from PIL import Image
from os import path
import presets

scale = presets.scale

def start_game():
    current_dir = path.dirname(path.abspath(__file__))
    sciezka_do_pliku = path.join(current_dir, "game.pyw")
    Popen([sys.executable, sciezka_do_pliku])
    app.destroy()
    exit()

def open_upgrade_menu():
    current_dir = path.dirname(path.abspath(__file__))
    sciezka_do_pliku = path.join(current_dir, "upgrade_menu.pyw")
    Popen([sys.executable, sciezka_do_pliku])
    app.destroy()
    exit()

def on_close():
    app.destroy()
    exit()

app = CTk()
app.title("2048 - Główne Menu")
app.geometry(f"{int(scale * 260)}x{int(scale * 200 - 42)}")
app.resizable(False,False)
app.protocol("WM_DELETE_WINDOW", on_close)


current_dir = path.dirname(path.abspath(__file__))
settings_img = CTkImage(dark_image=Image.open(path.join(current_dir, "img/settings/settings_dark.png")), light_image=Image.open(path.join(current_dir, "img/settings/settings_light.png")))

title = CTkLabel(app, text="2048 - Menu", font=("Arial", int(scale * 18), "bold"))
title.place(rely=0.0,relx=0.5, anchor="n")

start_game_btn = CTkButton(app, text="Zacznij grę!", command=start_game)
start_game_btn.place(rely=0.5, relx=0.5, y=-30, anchor="center")

shop_btn = CTkButton(app, text="Ulepszenia", command=open_upgrade_menu)
shop_btn.place(rely=0.5, relx=0.5, y=30, anchor="center")

settings_btn = CTkButton(app, int(scale * 26), int(scale * 26), image=settings_img, text="")
settings_btn.place(rely=0.0, relx=1.0, x=-5, y=5, anchor="ne")

app.mainloop()
