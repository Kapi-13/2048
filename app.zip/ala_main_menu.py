from sys import executable, exit
from subprocess import Popen
from pathlib import Path

folder_projekt = Path(__file__).resolve().parent.parent
sciezka_upgrade = str(folder_projekt / "upgrade.py")
Popen([executable, sciezka_upgrade], cwd=folder_projekt)
exit()