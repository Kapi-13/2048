from pathlib import Path
from subprocess import Popen
from sys import executable

folder_projekt = Path(__file__).resolve().parent.parent
sciezka_upgrade = str(folder_projekt / "upgrade.py")
Popen([executable, sciezka_upgrade], cwd=folder_projekt)
