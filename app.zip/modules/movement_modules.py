# pyright: reportMissingTypeStubs=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportUnknownVariableType=false, reportOptionalSubscript = false
from customtkinter import CTkLabel, CTk, CTkFrame
from typing import Literal
from utils import utils

score = 0
best_score: int
score_label: CTkLabel
best_score_label: CTkLabel
app: CTk
top_frame: CTkFrame
scale: float


def set_score(score_lab: CTkLabel, best_sc: int, best_score_lab: CTkLabel, application: CTk, title_frame: CTkFrame, app_scale: float) -> None:
    global score_label
    global best_score
    global best_score_label
    global app
    global top_frame
    global scale
    scale = app_scale
    top_frame = title_frame
    app = application
    score_label = score_lab
    best_score = best_sc
    best_score_label = best_score_lab


def move_up(labels_grid: list[list[CTkLabel]]) -> None:
    for i in range(4):
        for j in range(4):
            check_next_labels("up", [i, j], labels_grid)
    utils.score.change(score_label, score, best_score, best_score_label, app, top_frame, scale)


def move_down(labels_grid: list[list[CTkLabel]]) -> None:
    for i in reversed(range(4)):
        for j in range(4):
            check_next_labels("down", [i, j], labels_grid)
    utils.score.change(score_label, score, best_score, best_score_label, app, top_frame, scale)


def move_left(labels_grid: list[list[CTkLabel]]) -> None:
    for i in range(4):
        for j in range(1, 4):
            check_next_labels("left", [i, j], labels_grid)
    utils.score.change(score_label, score, best_score, best_score_label, app, top_frame, scale)


def move_right(labels_grid: list[list[CTkLabel]]) -> None:
    for i in range(4):
        for j in reversed(range(3)):
            check_next_labels("right", [i, j], labels_grid)
    utils.score.change(score_label, score, best_score, best_score_label, app, top_frame, scale)


def check_next_labels(
    direction: Literal["up", "down", "left", "right"],
    position: list[int],
    labels_grid: list[list[CTkLabel]],
    in_for: bool = False,
    start_pos: list[int] | None = None,
) -> None:
    global score
    if in_for or labels_grid[position[0]][position[1]].cget("text") != "":
        if direction == "up":
            if not in_for:
                if position[0] == 0:
                    return
                else:
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    next_label = labels_grid[position[0] - 1][position[1]]
                    next_value = next_label.cget("text")
                    if next_value == value:
                        score += int(next_value) * 2
                        utils.refresh(next_label, str(int(next_value) * 2))
                        utils.refresh(label, "")
                    elif next_value == "":
                        check_next_labels(
                            direction,
                            [position[0] - 1, position[1]],
                            labels_grid,
                            True,
                            position,
                        )
                    else:
                        pass
            else:
                if position[0] == 0:
                    start_label = labels_grid[start_pos[0]][start_pos[1]]
                    start_value = start_label.cget("text")
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    if value == start_value:
                        score += int(value) * 2
                        utils.refresh(label, str(int(value) * 2))
                        utils.refresh(start_label, "")
                    elif value == "":
                        utils.refresh(start_label, "")
                        utils.refresh(label, start_value)
                    else:
                        next_free_label = labels_grid[position[0] + 1][position[1]]
                        utils.refresh(start_label, "")
                        utils.refresh(next_free_label, start_value)
                else:
                    start_label = labels_grid[start_pos[0]][start_pos[1]]
                    start_value = start_label.cget("text")
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    next_label = labels_grid[position[0] - 1][position[1]]
                    next_value = next_label.cget("text")
                    if next_value == start_value:
                        score += int(next_value) * 2
                        utils.refresh(next_label, str(int(next_value) * 2))
                        utils.refresh(start_label, "")
                    elif next_value == "":
                        check_next_labels(
                            direction,
                            [position[0] - 1, position[1]],
                            labels_grid,
                            True,
                            start_pos,
                        )
                    else:
                        utils.refresh(start_label, "")
                        utils.refresh(label, start_value)
        elif direction == "down":
            if not in_for:
                if position[0] == 3:
                    return
                else:
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    next_label = labels_grid[position[0] + 1][position[1]]
                    next_value = next_label.cget("text")
                    if next_value == value:
                        score += int(next_value) * 2
                        utils.refresh(next_label, str(int(next_value) * 2))
                        utils.refresh(label, "")
                    elif next_value == "":
                        check_next_labels(
                            direction,
                            [position[0] + 1, position[1]],
                            labels_grid,
                            True,
                            position,
                        )
                    else:
                        pass
            else:
                if position[0] == 3:
                    start_label = labels_grid[start_pos[0]][start_pos[1]]
                    start_value = start_label.cget("text")
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    if value == start_value:
                        score += int(value) * 2
                        utils.refresh(label, str(int(value) * 2))
                        utils.refresh(start_label, "")
                    elif value == "":
                        utils.refresh(start_label, "")
                        utils.refresh(label, start_value)
                    else:
                        next_free_label = labels_grid[position[0] - 1][position[1]]
                        utils.refresh(start_label, "")
                        utils.refresh(next_free_label, start_value)
                else:
                    start_label = labels_grid[start_pos[0]][start_pos[1]]
                    start_value = start_label.cget("text")
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    next_label = labels_grid[position[0] + 1][position[1]]
                    next_value = next_label.cget("text")
                    if next_value == start_value:
                        score += int(next_value) * 2
                        utils.refresh(next_label, str(int(next_value) * 2))
                        utils.refresh(start_label, "")
                    elif next_value == "":
                        check_next_labels(
                            direction,
                            [position[0] + 1, position[1]],
                            labels_grid,
                            True,
                            start_pos,
                        )
                    else:
                        utils.refresh(start_label, "")
                        utils.refresh(label, start_value)
        elif direction == "left":
            if not in_for:
                if position[1] == 0:
                    return
                else:
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    next_label = labels_grid[position[0]][position[1] - 1]
                    next_value = next_label.cget("text")
                    if next_value == value:
                        score += int(next_value) * 2
                        utils.refresh(next_label, str(int(next_value) * 2))
                        utils.refresh(label, "")
                    elif next_value == "":
                        check_next_labels(
                            direction,
                            [position[0], position[1] - 1],
                            labels_grid,
                            True,
                            position,
                        )
                    else:
                        pass
            else:
                if position[1] == 0:
                    start_label = labels_grid[start_pos[0]][start_pos[1]]
                    start_value = start_label.cget("text")
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    if value == start_value:
                        score += int(value) * 2
                        utils.refresh(label, str(int(value) * 2))
                        utils.refresh(start_label, "")
                    elif value == "":
                        utils.refresh(start_label, "")
                        utils.refresh(label, start_value)
                    else:
                        next_free_label = labels_grid[position[0]][position[1] + 1]
                        utils.refresh(start_label, "")
                        utils.refresh(next_free_label, start_value)
                else:
                    start_label = labels_grid[start_pos[0]][start_pos[1]]
                    start_value = start_label.cget("text")
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    next_label = labels_grid[position[0]][position[1] - 1]
                    next_value = next_label.cget("text")
                    if next_value == start_value:
                        score += int(next_value) * 2
                        utils.refresh(next_label, str(int(next_value) * 2))
                        utils.refresh(start_label, "")
                    elif next_value == "":
                        check_next_labels(
                            direction,
                            [position[0], position[1] - 1],
                            labels_grid,
                            True,
                            start_pos,
                        )
                    else:
                        utils.refresh(start_label, "")
                        utils.refresh(label, start_value)
        elif direction == "right":
            if not in_for:
                if position[1] == 3:
                    return
                else:
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    next_label = labels_grid[position[0]][position[1] + 1]
                    next_value = next_label.cget("text")
                    if next_value == value:
                        score += int(next_value) * 2
                        utils.refresh(next_label, str(int(next_value) * 2))
                        utils.refresh(label, "")
                    elif next_value == "":
                        check_next_labels(
                            direction,
                            [position[0], position[1] + 1],
                            labels_grid,
                            True,
                            position,
                        )
                    else:
                        pass
            else:
                if position[1] == 3:
                    start_label = labels_grid[start_pos[0]][start_pos[1]]
                    start_value = start_label.cget("text")
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    if value == start_value:
                        score += int(value) * 2
                        utils.refresh(label, str(int(value) * 2))
                        utils.refresh(start_label, "")
                    elif value == "":
                        utils.refresh(start_label, "")
                        utils.refresh(label, start_value)
                    else:
                        next_free_label = labels_grid[position[0]][position[1] - 1]
                        utils.refresh(start_label, "")
                        utils.refresh(next_free_label, start_value)
                else:
                    start_label = labels_grid[start_pos[0]][start_pos[1]]
                    start_value = start_label.cget("text")
                    label = labels_grid[position[0]][position[1]]
                    value = label.cget("text")
                    next_label = labels_grid[position[0]][position[1] + 1]
                    next_value = next_label.cget("text")
                    if next_value == start_value:
                        score += int(next_value) * 2
                        utils.refresh(next_label, str(int(next_value) * 2))
                        utils.refresh(start_label, "")
                    elif next_value == "":
                        check_next_labels(
                            direction,
                            [position[0], position[1] + 1],
                            labels_grid,
                            True,
                            start_pos,
                        )
                    else:
                        utils.refresh(start_label, "")
                        utils.refresh(label, start_value)
    else:
        return
