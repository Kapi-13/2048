# pyright: reportMissingTypeStubs=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportUnknownVariableType=false

from customtkinter import CTkLabel
def check_game_over(labels_grid: list[list[CTkLabel]]):
    for row in range(4):
        for column in range(4):
            value = labels_grid[row][column].cget("text")
            if value == "":
                return False
            neighbors_values = []
            if row - 1 >= 0:
                neighbors_values.append(labels_grid[row - 1][column].cget("text"))
            if row + 1 <= 3:
                neighbors_values.append(labels_grid[row + 1][column].cget("text"))
            if column - 1 >= 0:
                neighbors_values.append(labels_grid[row][column - 1].cget("text"))
            if column + 1 <= 3:
                neighbors_values.append(labels_grid[row][column + 1].cget("text"))
            for neighbor_value in neighbors_values:
                if value == neighbor_value:
                    return False
    return True

