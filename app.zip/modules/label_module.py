# pyright: reportMissingTypeStubs=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportUnknownVariableType=false
from customtkinter import CTkLabel
from random import randint, randrange
from utils.utils import refresh


def random_spawn(labels_grid: list[list[CTkLabel]]) -> None:
    random_pos = [randint(0, 3), randint(0, 3)]
    random_num = randrange(2, 5, 2)
    try:
        a = labels_grid[random_pos[0]][random_pos[1]]
        if a.cget("text") == "":
            refresh(a, str(random_num))
        else:
            random_spawn(labels_grid)
    except RecursionError:
        print("Brak miejsca!!!")
